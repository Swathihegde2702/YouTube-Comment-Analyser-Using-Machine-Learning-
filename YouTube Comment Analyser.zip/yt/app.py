from flask import Flask, render_template, request, jsonify
from googleapiclient.discovery import build
import re
import emoji
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from collections import Counter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
app = Flask(__name__)

# Function to fetch YouTube comments and perform sentiment analysis
def analyze_comments(video_id):
    # Initialize YouTube API
    API_KEY = 'AIzaSyAjhMntnR37aYp-wyQfyz_-PRYDc6e6nnY'
    youtube = build('youtube', 'v3', developerKey=API_KEY)
    
    # Fetch video details
    video_response = youtube.videos().list(
        part='snippet',
        id=video_id
    ).execute()
    
    # Extract uploader's channel ID
    uploader_channel_id = video_response['items'][0]['snippet']['channelId']
    
    # Fetch comments
    comments = []
    nextPageToken = None
    while len(comments) < 600:
        request = youtube.commentThreads().list(
            part='snippet',
            videoId=video_id,
            maxResults=100,
            pageToken=nextPageToken
        )
        response = request.execute()
        for item in response['items']:
            comment = item['snippet']['topLevelComment']['snippet']
            # Check if the comment is not from the video uploader
            if comment['authorChannelId']['value'] != uploader_channel_id:
                comments.append(comment['textDisplay'])
        nextPageToken = response.get('nextPageToken')
        if not nextPageToken:
            break
    
    # Filter relevant comments
    relevant_comments = []
    hyperlink_pattern = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
    threshold_ratio = 0.65
    for comment_text in comments:
        comment_text = comment_text.lower().strip()
        emojis = emoji.emoji_count(comment_text)
        text_characters = len(re.sub(r'\s', '', comment_text))
        if (any(char.isalnum() for char in comment_text)) and not hyperlink_pattern.search(comment_text):
            if emojis == 0 or (text_characters / (text_characters + emojis)) > threshold_ratio:
                relevant_comments.append(comment_text)
    
    # Perform sentiment analysis
    analyzer = SentimentIntensityAnalyzer()
    polarities = []
    positive_comments = []
    negative_comments = []
    neutral_comments = []
    for comment in relevant_comments:
        sentiment_score = analyzer.polarity_scores(comment)['compound']
        polarities.append(sentiment_score)
        if sentiment_score > 0.05:
            positive_comments.append(comment)
        elif sentiment_score < -0.05:
            negative_comments.append(comment)
        else:
            neutral_comments.append(comment)
    
    # Calculate average polarity
    avg_polarity = sum(polarities) / len(polarities)
    if avg_polarity>0.05:
        print("The Video has got a Positive response\n")
    elif avg_polarity<-0.05:
        print("The Video has got a Negative response\n")
    else:
        print("The Video has got a Neutral response\n")
        
    # Calculate percentages
    total_comments = len(relevant_comments)
    positive_percentage = (len(positive_comments) / total_comments) * 100
    negative_percentage = (len(negative_comments) / total_comments) * 100
    neutral_percentage = (len(neutral_comments) / total_comments) * 100
    
    # Generate bar chart
    labels = ['Positive', 'Negative', 'Neutral']
    comment_counts = [len(positive_comments), len(negative_comments), len(neutral_comments)]
    plt.bar(labels, comment_counts, color=['blue', 'red', 'grey'])
    plt.xlabel('Sentiment')
    plt.ylabel('Comment Count')
    plt.title('Sentiment Analysis of Comments')
    plt.savefig('C:\\Users\\swara\\Desktop\\yt\\static\\chart.png')
 # Save the chart as a static file
    plt.close()
    
    # Count word occurrences
    word_counts = Counter()
    for comment in relevant_comments:
        words = comment.lower().strip().split()
        word_counts.update(words)
    top_words = dict(word_counts.most_common(5))
    
    # Construct analysis result string
    analysis_results = f"""
    Positive Comments Percentage:{positive_percentage:.2f}%
    Negative Comments Percentage: {negative_percentage:.2f}%
    Neutral Comments Percentage: {neutral_percentage:.2f}%
    Top 5 most common words:
    {', '.join([f'{word}: {count}' for word, count in top_words.items()])}
    """
    return analysis_results

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    video_url = request.form['url']
    video_id = video_url[-11:]
    analysis_results = analyze_comments(video_id)
    return render_template('results.html', results=analysis_results)

if __name__ == '__main__':
    app.run(debug=True)
